import csv
import bcrypt
from faker import Faker
import random



def generate_estudio_csv(filename):
    fake = Faker()
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["studyID", "UniID", "estudios_realizados"])
        
        for study_id in range(1, 11):
            uni_id = random.randint(1, 10)
            estudios_realizados = fake.sentence(nb_words=4)
            writer.writerow([study_id, uni_id, estudios_realizados])

generate_estudio_csv("estudios.csv") 