import csv
import bcrypt
from faker import Faker
import random

def generate_usuario_csv(filename):
    fake = Faker()
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["userID", "nombre", "contraseña", "estudios", "habilidades"])  # Asegúrate de que los encabezados coincidan con tu tabla

        for user_id in range(1, 51):  # 50 usuarios
            nombre = fake.name()  # Nombre aleatorio
            password = fake.password()  # Contraseña aleatoria
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')  # Hash de la contraseña
            estudios = random.choice([None, random.randint(1, 10)])  # Puede ser None o un ID aleatorio de estudios
            habilidades = random.choice([None, random.randint(1, 10)])  # Puede ser None o un ID aleatorio de habilidades
            
            writer.writerow([user_id, nombre, hashed_password, estudios, habilidades])