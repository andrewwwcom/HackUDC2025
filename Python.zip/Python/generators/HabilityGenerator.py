import csv
from faker import Faker

def generate_habilidades_csv(filename):
    fake = Faker()
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["habilidadid", "habilidad"])

        for habilidad_id in range(1, 11):
            habilidad = fake.word()
            writer.writerow([habilidad_id, habilidad])

generate_habilidades_csv("habilidades.csv") 