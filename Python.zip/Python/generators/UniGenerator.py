import csv
from faker import Faker

def generate_universidad_csv(filename):
    fake = Faker()
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["UniID", "UniNombre", "Ciudad"])  # Encabezados

        for uni_id in range(1, 11):  # 10 universidades
            uni_nombre = fake.company()  # Nombre de la universidad
            ciudad = fake.city()  # Ciudad
            writer.writerow([uni_id, uni_nombre, ciudad])

generate_universidad_csv("universidades.csv")