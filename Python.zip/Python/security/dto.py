class UsuarioDTO:
    def __init__(self, user_id, nombre, estudios=None, habilidades=None):
        self.user_id = user_id
        self.nombre = nombre
        self.estudios = estudios
        self.habilidades = habilidades

    def to_dict(self):
        return {
            "userID": self.user_id,
            "nombre": self.nombre,
            "estudios": self.estudios,
            "habilidades": self.habilidades,
        }
