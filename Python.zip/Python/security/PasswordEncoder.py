import bcrypt

# Hashing
password = ""
hashed = bcrypt.hashpw(password, bcrypt.gensalt())

# Verificando
if bcrypt.checkpw(password, hashed):
    print("Contraseña válida")

else:
    print("Contraseña incorrecta")
