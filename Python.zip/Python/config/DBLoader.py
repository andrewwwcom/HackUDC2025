from flask import Flask, request, jsonify
import psycopg2
import concurrent.futures


# Conexión a la base de datos
def get_db_connection():
    conn = psycopg2.connect(
        dbname='GradiantDB',
        user='postgres',
        password='postgres',
        host='localhost',
        port='5432'
    )
    return conn
