import bcrypt
from flask import Flask, jsonify, request
from flask_jwt_extended import create_access_token, jwt_required, JWTManager, get_jwt_identity
import concurrent.futures
from DBLoader import get_db_connection
from datetime import timedelta
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
limiter = Limiter(get_remote_address)

app = Flask(__name__)
jwt = JWTManager(app)

app.config['JWT_SECRET_KEY'] = '3r#42f@d*G7v!1q^rY2u9W#l&mP9gJ#k8e3L'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=3)

@app.route('/login', methods=['POST'])
@limiter.limit("5/minute")
def login():
    data = request.get_json()
    dni = data.get('dni')
    contraseña = data.get('contraseña')
    
    if not dni or not contraseña:
        return jsonify({"error": "DNI y contraseña son obligatorios."}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT contraseña FROM Usuario WHERE dni = %s;", (dni,))
    user = cursor.fetchone()
    
    cursor.close()
    conn.close()
    
    if user is None:
        return jsonify({"error": "Usuario no encontrado."}), 404
    
    stored_hashed_password = user[0]
    if bcrypt.checkpw(contraseña.encode('utf-8'), stored_hashed_password.encode('utf-8')):
        
        access_token = create_access_token(identity=dni)
        return jsonify({"message": "Login exitoso", "access_token": access_token, "dni": dni}), 200
    else:
        return jsonify({"error": "Contraseña incorrecta."}), 401

@app.route('/private', methods=['GET'])
@limiter.limit("5/minute")
@jwt_required() # Solo accesible con un JWT válido
def private():

    dni_from_token = get_jwt_identity()
    
    dni_from_request = request.args.get('dni')

    if dni_from_token != dni_from_request:
        return jsonify({"error": "El DNI del token no coincide con el DNI de la solicitud."}), 403
    
    return jsonify({"message": f"Bienvenido al área privada, usuario {dni_from_request}\n Serás redirigido a la página de Inicio."}), 200

# Realizar consulta

def query_users_by_dni(dni):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Usuario WHERE dni = %s;", (dni,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

def query_users_by_name(nombre_usuario):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Usuario WHERE nombre = %s;", (nombre_usuario,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

def query_users_by_hability(habilidad):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Usuario WHERE habilidad = %s;", (habilidad,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

def query_users_by_surname(apellido):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Usuario WHERE apellido = %s;", (apellido,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

def query_users_by_email(correo):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Usuario WHERE correo = %s;", (correo,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

def query_users_by_telefono(telefono):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Usuario WHERE telefono = %s;", (telefono,))
    results = cursor.fetchall()
    cursor.close()
    conn.close()
    return results

@app.route('/search', methods=['GET'])
#@jwt_required()
def search():
    dni = request.args.get('dni')
    nombre = request.args.get('nombre')
    apellido = request.args.get('apellido')
    habilidad = request.args.get('habilidad')
    correo = request.args.get('correo')
    telefono = request.args.get('telefono')

    results = []
    if habilidad is not None:
        try:
            habilidad = int(habilidad)
        except ValueError:
            return jsonify({"error": "Habilidad debe ser un número entero."}), 400


    # Ejecutar consulta
    with concurrent.futures.ThreadPoolExecutor() as executor:
        if dni:
            future = executor.submit(query_users_by_dni, dni)
            results.extend(future.result())
        
        if nombre:
            future = executor.submit(query_users_by_name, nombre)
            results.extend(future.result())
        
        if habilidad is not None:
            future = executor.submit(query_users_by_hability, habilidad)
            results.extend(future.result())
        
        if apellido:
            future = executor.submit(query_users_by_surname, apellido)
            results.extend(future.result())

        if correo:
            future = executor.submit(query_users_by_email, correo)
            results.extend(future.result())

        if telefono:
            future = executor.submit(query_users_by_telefono, telefono)
            results.extend(future.result())

    return jsonify(results)


@app.route('/insert/user', methods=['PUT'])
#@jwt_required()
def insert_user():
    data = request.get_json()  # Obtener los datos JSON
    dni = data.get('dni')
    nombre = data.get('nombre')
    apellido = data.get('apellido')
    contraseña = data.get('contraseña')
    estudios = data.get('estudios')
    habilidad = data.get('habilidad')
    correo = data.get('correo')
    telefono = data.get('telefono')
    if not nombre or not apellido or not dni or not contraseña:
        return jsonify({"error": "Faltan datos obligatorios: dni, nombre, apellido, contraseña."}), 400

    try:
        if estudios is not None:
            estudios = int(estudios)
        if habilidad is not None:
            habilidad = int(habilidad)
    except ValueError:
        return jsonify({"error": "Los estudios y la habilidad deben ser números enteros."}), 400

    hashed_contraseña = bcrypt.hashpw(contraseña.encode('utf-8'), bcrypt.gensalt())

    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM Usuario WHERE dni = %s;", (dni,))
        if cursor.fetchone() is not None:
            return jsonify({"error": "El DNI ya está insertado."}), 400

        cursor.execute(
            "INSERT INTO Usuario (dni, nombre, apellido, contraseña, estudios, habilidad, correo, telefono) VALUES (%s, %s, %s, %s, %s, %s, %s, %s);",
            (dni, nombre, apellido, hashed_contraseña.decode('utf-8'), estudios, habilidad, correo, telefono)
        )
        conn.commit()  # Confirmar los cambios
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

    return jsonify({"message": "Usuario insertado con éxito."}), 201


@app.route('/insert/habilidad', methods=['PUT'])
#@jwt_required()
def insert_habilidad():
    data = request.get_json()
    habilidad_id = data.get('habilidadid')
    nombre_habilidad = data.get('habilidad')

    if not habilidad_id or not nombre_habilidad:
        return jsonify({"error": "Faltan datos obligatorios: habilidadid y nombre."}), 400

    try:
   
        habilidad_id = int(habilidad_id)
    except ValueError:
        return jsonify({"error": "habilidadid debe ser un número entero."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM habilidades WHERE habilidadid = %s;", (habilidad_id,))
    if cursor.fetchone() is not None:
        cursor.close()
        conn.close()
        return jsonify({"error": "La habilidad con este habilidadid ya existe."}), 400

    # Insertar la nueva habilidad
    cursor.execute(
        "INSERT INTO habilidades (habilidadid, habilidad) VALUES (%s, %s);",
        (habilidad_id, nombre_habilidad)
    )
    conn.commit()  # Confirmar los cambios
    cursor.close()
    conn.close()
    return jsonify({"message": "Habilidad insertada con éxito."}), 201



@app.route('/delete/user', methods=['DELETE'])
#@jwt_required()
def delete_user():
    data = request.get_json()  # Obtener los datos JSON del cuerpo de la solicitud
    dni = data.get('dni') # DNI del usuario a eliminar

    if not dni:
        return jsonify({"error": "Falta el DNI."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    # Verificar si el usuario existe
    cursor.execute("SELECT * FROM Usuario WHERE dni = %s;", (dni,))
    if cursor.fetchone() is None:
        cursor.close()
        conn.close()
        return jsonify({"error": "El usuario no existe."}), 404

    # Eliminar el usuario
    cursor.execute("DELETE FROM Usuario WHERE dni = %s;", (dni,))
    conn.commit()  # Confirmar los cambios
    cursor.close()
    conn.close()
    return jsonify({"message": "Usuario eliminado con éxito."}), 200

@app.route('/update/user', methods=['PATCH'])
#@jwt_required()
def update_user():
    data = request.get_json()

    dni = data.get('dni')
    if not dni:
        return jsonify({"error": "El DNI es obligatorio."}), 400

    # Obtener solo los campos a actualizar
    campos_a_actualizar = {}
    if 'nombre' in data:
        campos_a_actualizar['nombre'] = data['nombre']
    if 'apellido' in data:
        campos_a_actualizar['apellido'] = data['apellido']
    if 'contraseña' in data:
        hashed_contraseña = bcrypt.hashpw(data['contraseña'].encode('utf-8'), bcrypt.gensalt())
        campos_a_actualizar['contraseña'] = hashed_contraseña.decode('utf-8')
    if 'estudios' in data:
        try:
            campos_a_actualizar['estudios'] = int(data['estudios'])
        except ValueError:
            return jsonify({"error": "Estudios debe ser un número entero."}), 400
    if 'habilidad' in data:
        try:
            campos_a_actualizar['habilidad'] = int(data['habilidad'])
        except ValueError:
            return jsonify({"error": "Habilidad debe ser un número entero."}), 400
    if 'correo' in data:
        campos_a_actualizar['correo'] = data['correo']
    if 'telefono' in data:
        campos_a_actualizar['telefono'] = data['telefono']

    if not campos_a_actualizar:
        return jsonify({"error": "No hay datos para actualizar."}), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Usuario WHERE dni = %s;", (dni,))
    if cursor.fetchone() is None:
        cursor.close()
        conn.close()
        return jsonify({"error": "El usuario no existe."}), 404

    set_clause = ", ".join(f"{campo} = %s" for campo in campos_a_actualizar.keys())
    valores = list(campos_a_actualizar.values()) + [dni]

    query = f"UPDATE Usuario SET {set_clause} WHERE dni = %s;"
    
    cursor.execute(query, valores)
    conn.commit()
    
    cursor.close()
    conn.close()

    return jsonify({"message": "Usuario actualizado con éxito."}), 200


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

